document.addEventListener('DOMContentLoaded', () => {
    const artworksSection = document.getElementById('artGallery');

    // Fetch artworks data from the API
    fetch('http://localhost:3000/artGallery/getArts')
        .then(response => response.json())
        .then(artGallery => {
            console.log("Loaded artGallery");
            // Iterate over each artwork and create HTML elements to display them
            artGallery.forEach(artwork => {
                const artworkDiv = document.createElement('div');
                artworkDiv.classList.add('artwork');
                artworkDiv.innerHTML = `
                    <h2>${artwork.artName}</h2>
                    <p>Artist: ${artwork.artist}</p>
                    <p>Year: ${artwork.price}</p>
                    <hr>
                `;
                artworksSection.appendChild(artworkDiv);
            });
        })
        .catch(error => {
            console.error('Error fetching artworks:', error);
        });
});
