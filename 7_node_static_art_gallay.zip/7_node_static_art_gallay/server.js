const mongoose = require('mongoose');
const express = require('express');
const PORT = 3000;
const app = express();
const artGallery = require('./models/art_model')


mongoose.connect("mongodb://127.0.0.1:27017/art").then(()=> {
    console.log("Successfully connected to MongoDB")
    app.listen(PORT, ()=>{
        console.log(`Listening on port ${PORT}`);
    })
}).catch((err) => {
    console.error("Error connecting to MongoDB", err);
})

app.use(express.json());

app.post('/artGallery/postArt', async (req,res) => {
    try{
        const art = req.body;
        const doc = await artGallery.insertMany(art);
        res.send({doc});
    }catch(err){
        res.status(500).send("Internal Server Error");
    }
})

app.get('/artGallery/getArts',async(req,res) => {
    try{
        const arts = await artGallery.find();
        res.setHeader('Access-Control-Allow-Origin', '*');
        console.log("artGallery: " + arts)
        res.send(arts);
    }catch(err){
        res.status(500).send("Internal Server Error");
    }
});


// app.get('/artGallery/getArtsProxy', async (req, res) => {
//     try {
//         // Fetch artworks data from the backend server
//         console.log("here1");
//         const response = await fetch('http://localhost:3000/artGallery/getArts');
//         const artGallery = await response.json();
//         console.log("artGallery: " + artGallery)
//         res.json(artGallery);
//     } catch (error) {
//         console.error('Error proxying request:', error);
//         res.status(500).send('Internal Server Error');
//     }
// });


