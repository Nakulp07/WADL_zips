const mongoose = require('mongoose');

const artGallery = new mongoose.Schema(
    {
        artName : String,
        artist : String,
        country : String,
        price : Number 
    }
)

module.exports = mongoose.model('artGallery', artGallery);