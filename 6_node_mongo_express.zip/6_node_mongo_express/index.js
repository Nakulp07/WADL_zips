//import modules
const mongoose = require('mongoose');
const PORT = 3000;
const express = require('express');
const app = express();
const songDetails = require("./model")

//connect to DB
mongoose
  .connect("mongodb://127.0.0.1:27017/music", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("\n\nSuccessfully connected to MongoDB");
    app.listen(PORT, ()=>{
        console.log(`Listening on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Error connecting to MongoDB",err);
    process.exit();
  });

  app.use(express.json());

  app.post("/songDetails/insert", async(req, res) => {
    try{
        const songs = req.body;
        await songDetails.insertMany(songs);
        res.json("Successfully inserted the songs");
    }catch(err){
        console.error("Error inserting the songs",err);
        res.status(500).send("Internal Server Error");
    };
  })

  app.get("/songDetails/allSongs", async (req,res)=>{
    try{
        const songs = await songDetails.find();
        const number = await songDetails.countDocuments();
        console.log({number,songs});
        res.send({number,songs});
    }catch(err){
        console.error("Error getting the song details",err);
        res.status(500).send("Internal Server Error");
    }
  })

  app.get("/songDetails/:dir",async (req,res) => {
    try{
        const director = req.params.dir;
        const songs = await songDetails.find({musicDirector : director})
        res.json(songs);
    }catch(err){
        console.error("Error getting the song details",err);
        res.status(500).send("Internal Server Error");
    }
  })

  app.get("/songDetails/:dir/:singer",async (req,res) => {
    try{
        const director = req.params.dir;
        const singer = req.params.singer;
        const songs = await songDetails.find({musicDirector : director,singer:singer})
        res.json(songs);
    }catch(err){
        console.error("Error getting the song details",err);
        res.status(500).send("Internal Server Error");
    }
  })

  app.delete("/songDetails/:song", async(req,res)=>{
    try{
        const song = req.params.song;
        const doc = await songDetails.findOneAndDelete({songName:song});
        res.send({doc});
        console.log("song deleted successfully");
    }catch(err){
        res.status(500).send("Internal Server error");
    }
  })

  app.get("/songsinbrowser", async(req,res)=>{
    try{
        const count = await songDetails.countDocuments();
        const songs = await songDetails.find();

        let tableHTML = `
            <h1> Total Songs = ${count}</h1>
            <h2> List of songs</h2>
            <table border="2">
                <tr>
                    <th> id </th>
                    <th> song Name </th>
                    <th> film Name </th>
                    <th> Music Director </th>
                    <th> Singer </th>
                </tr>
        `; 

        songs.forEach(song => {
            tableHTML +=`
            <tr>
                <td> ${song._id} </td>
                <td> ${song.songName} </td>
                <td> ${song.filmName} </td>
                <td> ${song.musicDirector} </td>
                <td> ${song.singer} </td>
            </tr>
            `
        })

        tableHTML += `</table>`;

        res.send(tableHTML);
    }catch(err){
        console.log("Error getting the song details",err);
        res.status(500).send("Internal Server Error");
    }
  });







