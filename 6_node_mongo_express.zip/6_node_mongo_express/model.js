const mongoose = require('mongoose');

const SongDetails = new mongoose.Schema(
    {
        songName : String,
        filmName : String,
        musicDirector : String,
        singer : String,
        actor : String,
        actress : String
    }
)

module.exports = mongoose.model("songDetails",SongDetails);